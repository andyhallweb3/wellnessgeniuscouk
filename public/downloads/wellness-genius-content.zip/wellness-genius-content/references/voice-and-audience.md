# Wellness Genius — Voice, Tone, and Audience Reference

## Who Andy Is

Andy runs Wellness Genius (wellnessgenius.co.uk), a business intelligence platform for wellness professionals. He is a Senior Account Manager at Zoom Media Management during the day, and has built a personal brand and professional network of 16K+ LinkedIn followers and 2.6K newsletter subscribers. His positioning is at the **intersection of wellness industry expertise and practical AI/technology capability** — he understands both the business problems gym operators face and the tech that can solve them.

He is not a fitness influencer. He is not a generic "digital transformation" consultant. He is a credible industry insider who happens to understand technology better than most wellness operators.

---

## Primary Audience

**Core audience: Wellness industry professionals who run or manage businesses**

This includes:
- Gym operators and leisure centre managers
- Personal trainers running their own businesses
- Wellness studio owners
- Health and fitness brand managers
- Operators at large chains (e.g. Bannatyne, The Gym Group, Parkwood Leisure)

**What they care about:**
- Member retention and acquisition
- Revenue per member and operational efficiency
- Technology that actually works in a gym/leisure environment
- Staying ahead of industry trends without being sold to

**What they don't want:**
- Vague wellness philosophy
- Academic research dumps
- Tech jargon without business context
- Content that talks down to them

**Secondary audience: Wellness tech and AI vendors** who follow Andy because he's an informed buyer and influencer in the space.

---

## Voice and Tone

### The core voice: Confident industry insider

Andy speaks peer-to-peer. He's not broadcasting from a stage — he's sharing what he's learned, what he's seeing, and what he thinks smart operators should do about it. Think: the most informed person in the room who doesn't need to prove it.

### Tonal qualities

| Do | Don't |
|---|---|
| Specific and concrete | Vague and general |
| Practitioner language | Academic or corporate language |
| Direct and confident | Hedged and cautious |
| Plain English | Buzzword-heavy |
| Short sentences | Run-on sentences with multiple clauses |
| Evidence-led | Opinion without grounding |
| Forward-looking | Nostalgic or backward-looking |

### Specific things to avoid

These words and phrases are banned from Wellness Genius content:

- "holistic" (unless quoting someone else)
- "wellness journey"
- "transformative" / "game-changer" / "revolutionary"
- "In today's fast-paced world..."
- "I'm excited to share..."
- "Thrilled to announce..."
- "Passionate about..."
- "Synergy"
- "Leverage" (as a verb)
- "Delighted"
- Any version of "This is so important"

### How AI and tech must be framed

Andy's audience includes many people who are sceptical of, or overwhelmed by, AI/tech. Every AI or technology reference must be grounded in a business outcome:

❌ "AI can analyse member data at scale using machine learning algorithms"
✅ "AI can flag members likely to cancel before they do — giving operators a 2-week window to intervene"

❌ "The new SDK integrates with HealthKit and Health Connect APIs"
✅ "Members who track workouts automatically retain at 23% higher rates — and now operators can enable that without asking members to do anything extra"

Always: tech feature → business mechanism → operator outcome.

---

## Content Positioning by Format

### LinkedIn

LinkedIn is Andy's primary brand-building channel. The goal of every post is:
1. Demonstrate credibility and insight to new followers
2. Give existing followers something worth saving or sharing
3. Drive traffic to Wellness Genius or newsletter (secondary)

LinkedIn content should feel like hearing from the smartest person at an industry conference — someone who's done the work and is sharing the real takeaway, not the press release version.

**Engagement note:** Posts that perform well for Andy typically challenge a common assumption, cite a specific data point, or give operators something they can act on immediately.

### Newsletter (Wellness Genius)

The newsletter is for Andy's most engaged audience — 2.6K subscribers who actively opted in. This audience has a longer attention span and wants more depth.

Newsletter tone is slightly more analytical than LinkedIn. It's closer to a trusted industry briefing than a social media post. Think: something a busy gym operator would actually read over their morning coffee because it saves them time and makes them look smart in their next management meeting.

### AI Readiness Assessments and Strategy Content

This content appears on the Wellness Genius platform. It needs to feel authoritative and practical — like a consultant who's done this before, not a vendor trying to sell something. No fluff. Specific criteria, specific implications, specific next steps.

---

## Examples of Good Wellness Genius Content

### Good LinkedIn hook
"New research shows gym members who track 3+ sessions per week retain at 40% higher rates than those who track fewer. Most operators know this. Almost none of them have a system to act on it."

### Good newsletter opening
"Two things happened in wellness tech this week that most operators will miss. Here's why they shouldn't."

### Good strategy recommendation close
"The window for early adoption here is 12–18 months. After that, this becomes table stakes, not competitive advantage."

### What mediocre content sounds like (avoid this)
"The wellness industry is evolving rapidly, and AI presents exciting opportunities for operators to enhance member experiences. Here are some key considerations as you navigate this transformative landscape..."

---

## Andy's Key Projects and Themes (for contextual relevance)

When content can naturally connect to these themes, do so — but don't force it:

- **Motion+ SDK**: Gamification and activity tracking for gym operators (his Zoom Media project)
- **Member retention**: The central business challenge for most gym operators
- **AI in wellness**: Practical, not theoretical — assessment tools, business intelligence, operator decision-making
- **Leisure industry technology**: Screens, media, digital experience in gym environments
- **Wellness Genius platform**: BI tools for wellness professionals

These are the areas where Andy has genuine depth. Content in these areas can go deeper and be more specific.
