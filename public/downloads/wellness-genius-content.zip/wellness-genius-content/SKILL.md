---
name: wellness-genius-content
description: Wellness Genius content creation workflow for Andy at wellnessgenius.co.uk. Use when user shares a news article, research, trend, or topic and wants to create LinkedIn posts, newsletter sections, AI readiness assessments, business strategy recommendations, or repurposed content. Triggers on phrases like "turn this into a post", "write a newsletter section", "content from this article", "LinkedIn post about", "repurpose this", "create content from", "write up this research", or any request to produce wellness industry content for a professional audience.
metadata:
  author: Andy - Wellness Genius
  version: 1.0.0
  category: content-creation
---

# Wellness Genius Content Creation

A workflow skill for producing high-quality, on-brand content for Wellness Genius (wellnessgenius.co.uk) — a business intelligence platform for wellness professionals. Andy has 16K+ LinkedIn followers and 2.6K newsletter subscribers. Every piece of content must reflect his positioning at the intersection of wellness expertise and tech/AI capabilities.

Before producing any content, read `references/voice-and-audience.md` to apply tone, voice, and audience guidance correctly.

---

## Workflow Overview

Every content request follows this five-step sequence:

1. **Identify the content type(s) requested**
2. **Extract the research angle** — find the sharpest insight in what's been shared
3. **Apply tone and voice** from references
4. **Produce all requested formats** with variants where needed
5. **Add CTAs, hashtags, and distribution notes**

Never skip steps 2 or 3. The research angle and voice are what make this content stand out.

---

## Step 1: Identify Content Type

Determine which output(s) are needed based on the user's request:

| Code | Content Type | Typical Length |
|------|-------------|----------------|
| LI | LinkedIn post | 150–300 words (short) or 300–600 words (long) |
| NL | Newsletter section | 200–400 words |
| AI | AI readiness assessment content | 300–500 words |
| BS | Business strategy recommendation | 250–450 words |
| RP | Repurposed content (long → short) | Condensed to 150–250 words |

If the user hasn't specified, default to producing LI (short + long variants) and NL together, as these are the most common combination.

---

## Step 2: Extract the Research Angle

Before writing anything, identify:

- **The core insight**: What's the single most important or surprising finding?
- **The professional implication**: Why does this matter to wellness professionals specifically?
- **The contrarian or forward-looking take**: What do most people miss, or what's coming next?
- **The data point or quote**: Is there a stat, figure, or quote that anchors the piece?

State the research angle clearly before producing content. Example format:

```
RESEARCH ANGLE:
Core insight: [one sentence]
Professional implication: [one sentence]
Contrarian take: [one sentence]
Anchor data point: [stat or quote if available]
```

This step is non-negotiable. If the input is vague, ask one clarifying question before proceeding.

---

## Step 3: Apply Tone and Voice

Read `references/voice-and-audience.md` now if you haven't already.

Key rules (summary):
- Confident but not arrogant — lead with insight, not opinion
- Practitioner-to-practitioner tone, never academic or corporate
- AI and tech must always be framed in terms of business outcomes for wellness operators
- Never use generic wellness clichés (e.g. "holistic", "wellness journey", "transformative")
- Use plain, specific language. Short sentences. Active voice.

---

## Step 4: Produce Content Formats

### LinkedIn Posts (LI)

Always produce TWO variants — short and long — unless the user specifies one.

**Short variant (150–300 words):**
- Hook line (first 2 lines must stop the scroll — no "I'm excited to share...")
- 3–5 punchy paragraphs or a short numbered list
- One clear takeaway
- CTA (see Step 5)

**Long variant (300–600 words):**
- Strong opening hook
- Context or backstory (2–3 sentences)
- Core insight unpacked with evidence
- Practical implication for wellness professionals
- Forward-looking close
- CTA

**Hook formats that work well for this audience:**
- Provocative question: "Why are 80% of gym operators still ignoring X?"
- Surprising stat: "New research shows X. Here's what it means for your business."
- Contrarian opener: "Everyone's talking about X. But the real story is Y."
- Direct value: "3 things wellness operators need to know about [topic]:"

---

### Newsletter Sections (NL)

Structure:
1. **Headline** (8–12 words, benefit-led)
2. **Opening hook** (1–2 sentences)
3. **The insight** (2–3 paragraphs — what it is, why it matters, what to do)
4. **Quick takeaway box** (3 bullet points max, labelled "Key takeaways:")
5. **Link or resource** (if available from source material)

Tone for newsletter: slightly more detailed and analytical than LinkedIn. This audience reads to learn, not just to engage.

---

### AI Readiness Assessment Content (AI)

Used for Wellness Genius assessment tools deployed on the platform.

Structure:
1. **Context framing** — why this assessment area matters for wellness businesses
2. **Assessment criteria** — 3–5 specific, measurable indicators of readiness
3. **Scoring guidance** — what low/medium/high readiness looks like in practice
4. **Recommended next step** — one concrete action for each readiness level

Keep language operational. Wellness professionals using this tool are practitioners, not technologists.

---

### Business Strategy Recommendations (BS)

Structure:
1. **Situation** — what the current landscape looks like (1 short paragraph)
2. **Opportunity** — the specific strategic opening available (1 short paragraph)
3. **Recommended action** — what to do, concretely and specifically
4. **Why now** — timing rationale (1–2 sentences)
5. **Risk or caveat** — one honest consideration

Do not hedge excessively. These are recommendations, not academic analyses.

---

### Content Repurposing (RP)

When repurposing long-form content to short:

1. Identify the single strongest idea in the source
2. Strip everything that doesn't serve that idea
3. Rewrite in the Wellness Genius voice (do not just summarise — reframe for the platform)
4. Confirm the repurposed version stands alone without needing the source

---

## Step 5: CTAs, Hashtags, and Distribution Notes

### CTAs

Always end LinkedIn posts and newsletter sections with a CTA. Match the CTA to the content type:

| Content type | Suggested CTA style |
|---|---|
| Educational insight | "What's your take? Drop a comment below." |
| Research/data | "Save this for your next strategy session." |
| Tool or framework | "Try this with your team this week." |
| Opinion/trend | "Follow for more wellness industry intelligence." |
| Newsletter | "Subscribe to Wellness Genius for weekly insights → wellnessgenius.co.uk" |

### Hashtags (LinkedIn only)

Provide 5–8 hashtags. Always include:
- `#WellnessGenius`
- `#WellnessIndustry`
- `#FitnessIndustry`

Add 2–5 topic-specific hashtags relevant to the content (e.g. `#AIinFitness`, `#GymOperator`, `#MemberRetention`, `#WellnessTech`, `#HealthData`).

### Distribution Notes

After producing content, add a brief note:

```
DISTRIBUTION NOTES:
Best for LinkedIn: [short or long variant, and why]
Newsletter fit: [yes/no, and which section it suits]
Repurpose potential: [what else this could become]
```

---

## Quality Check Before Finalising

Before presenting output, verify:

- [ ] Research angle was identified and is reflected in the content
- [ ] No wellness clichés used
- [ ] Hook is strong enough to stop the scroll / open the email
- [ ] AI/tech framed in business outcome terms (not feature terms)
- [ ] CTA is included
- [ ] Hashtags provided for LinkedIn content
- [ ] Both short and long variants produced for LinkedIn (unless specified otherwise)

---

## Common Issues

**User shares a long article with no specific ask**
→ Default to producing LI short + long and NL section. State the research angle first, then ask if the direction is right before writing full drafts.

**Content feels generic**
→ Return to Step 2. The research angle hasn't been sharp enough. Find the contrarian take or the data point that makes it specific.

**User asks to "just make it shorter"**
→ This is a repurposing task (RP). Don't just truncate — rewrite from the core insight up.

**AI or tech topic with no clear wellness angle**
→ Always bridge to: how does this affect wellness operators' revenue, retention, or operational efficiency? If you can't make that bridge, ask Andy before proceeding.
